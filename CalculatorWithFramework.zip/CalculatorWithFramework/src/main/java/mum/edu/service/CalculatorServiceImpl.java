package mum.edu.service;

import mum.edu.domain.Calculator;

public class CalculatorServiceImpl implements CalculatorService {
    @Override
    public void add(Calculator calculator) {
        calculator.add();
    }

    @Override
    public void mult(Calculator calculator) {
        calculator.mult();

    }
}
