package mum.edu.validator;

import mum.edu.domain.Calculator;

import java.util.ArrayList;
import java.util.List;

public class CalculatorValidatorImpl implements CalculatorValidator {
    @Override
    public List<String> validate(Object object) {
        List<String> errors = new ArrayList<String>();

        Calculator calculator = (Calculator)object;

        if(calculator.getAdd1() == null){
            errors.add("You must Provide a value for Addition");
        }
        if(calculator.getAdd2() == null){
            errors.add("You must Provide a value for Addition");
        }
        if(calculator.getMult1() == null){
            errors.add("You must Provide a value for Multiplication");
        }
        if(calculator.getMult2() == null){
            errors.add("You must Provide a value for Multiplication");
        }
        return errors;
    }
}
