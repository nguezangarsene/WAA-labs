package mum.edu.validator;

import java.util.List;

public interface CalculatorValidator {
    public List<String> validate(Object object);
}
