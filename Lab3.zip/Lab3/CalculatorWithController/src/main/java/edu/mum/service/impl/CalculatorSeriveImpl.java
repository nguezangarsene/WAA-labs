package edu.mum.service.impl;

import edu.mum.domain.Calculator;
import edu.mum.service.CalculatorService;
import org.springframework.stereotype.Service;

@Service
public class CalculatorSeriveImpl implements CalculatorService {

    public void add(Calculator calculator) {
        calculator.add();
        return;

    }

    public void mult(Calculator calculator) {
        calculator.mult();
        return;
    }

}
