 import { Category } from '../../category/shared/category';

export class Product {
  id: number;
  name: string;
  description: string;
  price: number;
 category: Category;

    constructor() {
    this.category = new Category();
  }

}
